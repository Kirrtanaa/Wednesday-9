import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserServiceService } from '../user-service.service';
import { CurrentTraining } from '../user';

@Component({
  selector: 'app-current-training',
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {


  // constructor(private httpservice : HttpClient) { }

  // course : string[];

  // ngOnInit() {
  //   this.httpservice.get('../../assets/userCurrent.json').subscribe(

  //     data=>{
  //       this.course = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )
  // }

  private technology=[];

  constructor(private user:UserServiceService){}
  private mcurrent:string[];

  
  // constructor(private httpservice : HttpClient) { }

  // ngOnInit() {
  //   this.httpservice.get('../../assets/mentordetails.json').subscribe(

  //     data=>{
  //       this.mentor = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )

  //   this.httpservice.get('../../assets/userdetails.json').subscribe(

  //     data=>{
  //       this.users = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )
  // }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    // this.user.getmentor().subscribe(value=>this.mentor=value as string[]);
    // this.user.getcompleted().subscribe(value=>this.mcompleted=value as string[]);
    this.user.getcurrent().subscribe(value=>this.mcurrent=value as string[]);
  }

  search(){
   var input, filter, table, tr, td, td1, i, txtValue, txtValue1;
   input = document.getElementById("find");
   filter = input.value.toUpperCase();
   table = document.getElementById("myTable");
   tr = table.getElementsByTagName("tr");
   for (i = 0; i < tr.length; i++) {
     td = tr[i].getElementsByTagName("td")[2];
     td1 = tr[i].getElementsByTagName("td")[1];
     if (td!=null || td1!=null) {
      txtValue = td.textContent || td.innerText;
      txtValue1 = td1.textContent || td1.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1 || txtValue1.toUpperCase().indexOf(filter) > -1) tr[i].style.display = ""; 
      else tr[i].style.display = "none";
     }    
    }
  }

}
