import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor',
  templateUrl: './mentor.component.html',
  styleUrls: ['./mentor.component.css']
})
export class MentorComponent implements OnInit {

  email : string;
  password : string;

  constructor(private mentorLogin: Router) { }

  ngOnInit() {
  }
  submit() {
    if(this.email==null) {
      alert("Enter Valid Email Address");
    }else if(this.password==null) {
      alert("Enter password");
    }else {
      this.mentorLogin.navigate(['/mentor-logged']);
    }
  }
}
