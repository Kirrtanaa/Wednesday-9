import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

// import { EditTechnology } from './addskill';



@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  private baseURL = "http://localhost:8080/api/phase4";
 
  constructor(private http: HttpClient) { }

  /****************************************USER************************************************* */
  getmentor():Observable<any>{ 
    return this.http.get(`${this.baseURL}-mentor/mentor/profile`);
  }

  getcompleted():Observable<any>{ 
    return this.http.get(`${this.baseURL}-user/user/completed`);
  }

  getcurrent():Observable<any>{ 
    return this.http.get(`${this.baseURL}-user/user/current`);
  }

  /****************************************MENTOR************************************************* */
  getmentorcurrent():Observable<any>{ 
    return this.http.get(`${this.baseURL}-mentor/mentor/current`);
  }

  getmentorcompleted():Observable<any>{ 
    return this.http.get(`${this.baseURL}-mentor/mentor/completed`);
  }

  /****************************************ADMIN************************************************* */
  getblockusers():Observable<any>{ 
    return this.http.get(`${this.baseURL}-user/user/training`);
  } 

  getblockmentors():Observable<any>{ 
    return this.http.get(`${this.baseURL}-mentor/mentor/profile`);
  } 

  savetechnology(tech:string):Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/addskill/${tech}`);
  }

  removetechnology(tech:string):Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/remove/${tech}`);
  }

  displaytechnology():Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/allskills`);
  }

  /****************************************LOGINS************************************************* */
  saveUser(user:object){
    return this.http.post(`${this.baseURL}-security/main/addentry`,user);
  }


}
