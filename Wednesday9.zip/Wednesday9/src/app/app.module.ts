import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { AdminLoggedComponent } from './admin-logged/admin-logged.component';
import { UserComponent } from './user/user.component';
import { AvailableCoursesComponent } from './available-courses/available-courses.component';
import { CompletedTrainingComponent } from './completed-training/completed-training.component';
import { CompletedTrainMentorComponent } from './completed-train-mentor/completed-train-mentor.component';
import { CurrentTrainingComponent } from './current-training/current-training.component';
import { CurrentTrainMentorComponent } from './current-train-mentor/current-train-mentor.component';
import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import { EditTechnologyComponent } from './edit-technology/edit-technology.component';
import { LoginComponent } from './login/login.component';
import { MainPageComponent } from './main-page/main-page.component';
import { MentorComponent } from './mentor/mentor.component';
import { MentorDetailsComponent } from './mentor-details/mentor-details.component';
import { MentorLoggedComponent } from './mentor-logged/mentor-logged.component';
import { MentorRegisterComponent } from './mentor-register/mentor-register.component';
import { PaymentsComponent } from './payments/payments.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { UserLoggedComponent } from './user-logged/user-logged.component';
import { UserRegisterComponent } from './user-register/user-register.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    AdminLoggedComponent,
    UserComponent,
    AvailableCoursesComponent,
    CompletedTrainingComponent,
    CompletedTrainMentorComponent,
    CurrentTrainingComponent,
    CurrentTrainMentorComponent,
    EditSkillsComponent,
    EditTechnologyComponent,
    LoginComponent,
    MainPageComponent,
    MentorComponent,
    MentorDetailsComponent,
    MentorLoggedComponent,
    MentorRegisterComponent,
    PaymentsComponent,
    UserDetailsComponent,
    UserLoggedComponent,
    UserRegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
